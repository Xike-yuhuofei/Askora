(function() {
  var style = getComputedStyle(document.documentElement);
  var accent = style.getPropertyValue('--accent').trim();
  var accent2 = style.getPropertyValue('--accent2').trim();
  var ink = style.getPropertyValue('--ink').trim();
  var muted = style.getPropertyValue('--muted').trim();
  var rule = style.getPropertyValue('--rule').trim();
  var bg2 = style.getPropertyValue('--bg2').trim();

  // --- Chart: Cost Comparison ---
  var chartCost = echarts.init(document.getElementById('chart-cost-compare'), null, { renderer: 'svg' });

  var categories = ['输入 Token\n(百万)', '输出 Token\n(百万)', 'Embedding\n(百万)', '内容安全审核\n(每千次)', '综合单用户\n成本/月'];

  // 相对值对比，以 GPT-4o 方案为 100
  var overseasData = [100, 100, 100, 0, 100];
  var chinaData = [35, 45, 25, 15, 75];

  chartCost.setOption({
    animation: false,
    tooltip: {
      trigger: 'axis',
      appendToBody: true,
      axisPointer: { type: 'shadow' },
      formatter: function(params) {
        var html = params[0].axisValue + '<br/>';
        params.forEach(function(p) {
          html += p.marker + p.seriesName + ': ' + p.value + '%<br/>';
        });
        return html;
      }
    },
    legend: {
      data: ['原方案（GPT-4o + 出海）', '中国市场方案（国产模型）'],
      bottom: 0,
      textStyle: { color: muted, fontSize: 12 }
    },
    grid: {
      left: '3%',
      right: '4%',
      bottom: '15%',
      top: '8%',
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: categories,
      axisLabel: {
        color: muted,
        fontSize: 11,
        interval: 0
      },
      axisLine: { lineStyle: { color: rule } },
      axisTick: { show: false }
    },
    yAxis: {
      type: 'value',
      name: '相对成本 (%)',
      nameTextStyle: { color: muted, fontSize: 11 },
      axisLabel: {
        color: muted,
        fontSize: 11,
        formatter: '{value}%'
      },
      axisLine: { show: false },
      axisTick: { show: false },
      splitLine: { lineStyle: { color: rule, type: 'dashed' } }
    },
    series: [
      {
        name: '原方案（GPT-4o + 出海）',
        type: 'bar',
        data: overseasData,
        itemStyle: {
          color: muted,
          borderRadius: [4, 4, 0, 0]
        },
        barWidth: '30%'
      },
      {
        name: '中国市场方案（国产模型）',
        type: 'bar',
        data: chinaData,
        itemStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: accent },
            { offset: 1, color: accent2 }
          ]),
          borderRadius: [4, 4, 0, 0]
        },
        barWidth: '30%'
      }
    ]
  });

  window.addEventListener('resize', function() {
    chartCost.resize();
  });
})();
